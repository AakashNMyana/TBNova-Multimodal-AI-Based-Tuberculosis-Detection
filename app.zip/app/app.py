import tensorflow as tf
import gradio as gr
from PIL import Image
import numpy as np
import os
import joblib
import librosa
import textwrap

# --- Define Constants and File Paths ---
MODEL_DIR = os.path.join('..', 'saved_models')
CXR_MODEL_PATH = os.path.join(MODEL_DIR, 'cxr_best_model.h5')
AUDIO_MODEL_PATH = os.path.join(MODEL_DIR, 'audio_dl_model.h5')
SCALER_PATH = os.path.join(MODEL_DIR, 'audio_scaler.joblib')

# --- Fusion Weights ---
CXR_WEIGHT = 0.70
AUDIO_WEIGHT = 0.30

# --- Load All Models and Tools ---
try:
    print("Loading all models, please wait...")
    cxr_model = tf.keras.models.load_model(CXR_MODEL_PATH)
    audio_model = tf.keras.models.load_model(AUDIO_MODEL_PATH)
    audio_scaler = joblib.load(SCALER_PATH)
    print("All models and scaler loaded successfully.")
except Exception as e:
    print(f"Error loading models. Error: {e}")
    cxr_model = None

# --- MFCC Feature Extraction Function ---
def extract_mfcc_feature(audio_path):
    try:
        y, sr = librosa.load(audio_path, sr=16000, duration=10)
        mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=40)
        mfccs_mean = np.mean(mfccs.T, axis=0)
        feature_vector = mfccs_mean.reshape(1, -1)
        scaled_feature = audio_scaler.transform(feature_vector)
        return scaled_feature
    except Exception as e:
        print(f"MFCC feature extraction failed: {e}")
        return None

# --- Main Prediction Function (Now returns multiple outputs for the new UI) ---
def multimodal_predict(cxr_image, cough_audio):
    
    # Default probabilities
    cxr_prob, audio_prob = 0.5, 0.5
    
    if cxr_image is not None:
        try:
            img = cxr_image.resize((224, 224)).convert('RGB')
            img_array = np.array(img)
            img_batch = np.expand_dims(img_array, axis=0)
            cxr_prob = cxr_model.predict(img_batch, verbose=0)[0][0]
        except Exception as e:
            print(f"CXR prediction failed: {e}")

    if cough_audio is not None:
        try:
            audio_path = cough_audio
            audio_feature = extract_mfcc_feature(audio_path)
            if audio_feature is not None:
                audio_prob = audio_model.predict(audio_feature, verbose=0)[0][0]
        except Exception as e:
            print(f"Audio prediction failed: {e}")

    # --- FUSION (Weighted Average) ---
    final_prob = (cxr_prob * CXR_WEIGHT) + (audio_prob * AUDIO_WEIGHT)
    
    # --- 1. Prepare Output for the Main Label Component ---
    # This dictionary with floats is what gr.Label needs for the confidence bars.
    label_output = {'Tuberculosis': float(final_prob), 'Normal': 1 - float(final_prob)}
    
    # --- 2. Prepare Output for the Breakdown Text ---
    breakdown_output = f"""
    ### 📊 Prediction Breakdown
    *   **CXR Model (TB Probability):** `{float(cxr_prob):.2%}`
    *   **Audio Model (TB Probability):** `{float(audio_prob):.2%}`
    """
    
    # --- 3. Prepare Output for the Guidance Text ---
    if final_prob > 0.70: # High Urgency
        guidance_output = textwrap.dedent("""
        ### ⚠️ High Urgency: Immediate Action Recommended
        *   **Consult a Doctor Immediately:** This result indicates a high probability of TB.
        *   **Show these Results:** Present this screening report to your healthcare provider.
        *   **Prepare for Confirmatory Tests:** Your doctor will advise on next steps.
        """)
    elif final_prob > 0.50: # Moderate Urgency
        guidance_output = textwrap.dedent("""
        ### 📋 Moderate Urgency: Follow-Up Recommended
        *   **Schedule a Doctor's Visit:** Discuss these results and any symptoms with a healthcare professional.
        *   **Monitor Your Health:** Pay attention to any persistent cough or unexplained weight loss.
        """)
    else: # Low Urgency / Normal
        guidance_output = textwrap.dedent("""
        ### ✅ Low Urgency: No Immediate Action Required
        *   **Low Probability Detected:** The screening result is negative for TB.
        *   **Continue to Monitor Health:** If symptoms develop or worsen, please consult a doctor.
        *   **Disclaimer:** This is an AI screening tool, not a medical diagnosis.
        """)
        
    return label_output, breakdown_output, guidance_output

# --- Build the Gradio Interface using Blocks for a Custom Layout ---
with gr.Blocks(theme=gr.themes.Soft(primary_hue=gr.themes.colors.purple, secondary_hue=gr.themes.colors.blue)) as interface:
    gr.Markdown("# Multimodal Deep Learning for Tuberculosis Detection")
    gr.Markdown("This app fuses predictions from a CXR model and an audio model. Upload an image and an optional audio file, then click Submit.")
    
    with gr.Row():
        with gr.Column(scale=1):
            cxr_input = gr.Image(type="pil", label="1. Upload Chest X-Ray Image", show_download_button=False)
            audio_input = gr.Audio(type="filepath", label="2. Upload Cough Audio File (Optional)")
            with gr.Row():
                clear_btn = gr.ClearButton()
                submit_btn = gr.Button("Submit", variant="primary")
                
        with gr.Column(scale=1):
            # NEW: Define the three separate output components for a clean UI
            final_pred_label = gr.Label(label="Final Fused Prediction")
            breakdown_md = gr.Markdown(label="Breakdown")
            guidance_md = gr.Markdown(label="Recommended Next Steps")

    # --- Define the interactions ---
    submit_btn.click(
        fn=multimodal_predict,
        inputs=[cxr_input, audio_input],
        # The outputs now map to our three new components
        outputs=[final_pred_label, breakdown_md, guidance_md]
    )
    
    # The ClearButton needs to clear all inputs and all outputs
    clear_btn.click(lambda: (None, None, None, None, None), 
                    inputs=[], 
                    outputs=[cxr_input, audio_input, final_pred_label, breakdown_md, guidance_md])

# --- Launch the Web App ---
if __name__ == "__main__":
    if cxr_model:
        interface.launch()
    else:
        print("Web app not launched due to model loading error.")